<?php
/**
 * Plain Text Email Template: Footer
 *
 * This template can be overridden by copying it to yourtheme/gamipress/emails/footer.php
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// This is the footer used if no others are available

?>
    </body>
</html>